# Liver Patient Classifier 
This model classify either the patient has liver disease or not based upon some specific features.
